//
//  PMFileHelper.h
//  photo_manager
//
//  Created by Caijinglong on 2020/1/14.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

///  Contains access file methods
@interface PMFileHelper : NSObject

+(void)deleteFile:(NSString *)path;

@end

NS_ASSUME_NONNULL_END
