//
//  PMImport.h
//  Pods
//
//  Created by jinglong cai on 2021/4/13.
//
//

#ifndef PMImport_h
#define PMImport_h

#if TARGET_OS_OSX
#import <FlutterMacOS/FlutterMacOS.h>
#elif TARGET_OS_IOS
#import <Flutter/Flutter.h>
#endif

#endif /* PMImport_h */
